RP^3:?^32D9

7G0=:DE0AC67:IWXL
  A0:?56IlS`j
  FD6ClS&$t#j
  9@DElSw~$%}p|t
  J62Cl152E6 VZT*V1
  >@?E9l152E6 VZT>V1
  52Jl152E6 VZT5V1
  E:>6l152E6 VZTwiT|iT$V1
  9@DE0=6?8E9l1649@ \? S9@DE M H4 \>1
  FD6C0=6?8E9l1649@ \? SFD6C M H4 \>1
  E@E2=0=6?8E9lSWWS9@DE0=6?8E9ZSFD6C0=6?8E9XXj

  :7 , SA0:?56I \6B Q_Q .j E96?
    A0:?56Il`
  7:j

  9@DE0:?56IlSA0:?56I
  FD6C0:?56IlSA0:?56I

  :7 , SA0:?56I \8E S9@DE0=6?8E9 .j E96?
    9@DE0:?56IlSWWS9@DE0:?56ITS9@DE0=6?8E9XX
  7:j

  :7 , SA0:?56I \8E SFD6C0=6?8E9 .j E96?
     FD6C0:?56IlSWWSFD6C0:?56ITSFD6C0=6?8E9XX
  7:j

  :7 , S9@DE0:?56I \6B Q_Q .j E96?
    9@DE0:?56IlS9@DE0=6?8E9j
  7:j

  :7 , SFD6C0:?56I \6B Q_Q .j E96?
    FD6C0:?56IlSFD6C0=6?8E9j
  7:j

  =6EE6C09@DElSW649@ S9@DE M 4FE \4S9@DE0:?56IX
  =6EE6C0FD6ClSW649@ SFD6C M 4FE \4SFD6C0:?56IX

  C@Hl1649@ __S9@DE0:?56I M E2:= \4c1
  C@HZl1649@ __SE@E2=0=6?8E9 M E2:= \4c1
  C@HZlQ\Q
  C@HZl1649@ QS=6EE6C0FD6CQ M EC V,i=@H6Ci.V V,iFAA6Ci.V1 
  C@HZlQSJ62C\Q
  C@HZl1649@ _S>@?E9 M E2:= \4b1
  C@HZlQ\Q
  C@HZl1649@ _S52J M E2:= \4b1
  C@HZl1649@ QS=6EE6C09@DEQ M EC V,i=@H6Ci.V V,iFAA6Ci.V1 
  C@HZlQSE:>6Q
  649@ SC@Hj
N

7G096256CWXL

  76492l152E6 VZT*\T>\T5 TwiT|iT$V1
  9@DE0=6?8E9lSLRw~$%}p|tN
  FD6C0=6?8E9lSLR&$t#N
  92D9lSWWS9@DE0=6?8E9ZSFD6C0=6?8E9XX
  4@?7:8w@DEDl142E ^6E4^9@DED M 8C6A Q7:]F?2>Q1
  4@?7:8w@DE?2>6l142E ^6E4^9@DE?2>6 M 8C6A Q7:]F?2>Q1

  649@ Qllllllllll '2=:524:@? 56 C6DF=E25@D llllllllll Qj
  649@ Q`] u6492]]]]]]]]]]]]]]]]]]]]]]]]]]]]SL76492NQ
  649@ Qa] }@>3C6 56= w@DE ]]]]]]]]]]]]]]]] SLw~$%}p|tNQ
  649@ Qb] }@>3C6 56= FDF2C:@ ]]]]]]]]]]]]] SL&$t#NQ
  649@ Qc] r@?7:8 ^6E4^9@DED  ]]]]]]]]]]]]] SL4@?7:8w@DEDNQ
  649@ Qd] r@?7:8 ^6E4^9@DE?2>6 ]]]]]]]]]]] SL4@?7:8w@DE?2>6NQ
  649@ Qe] 7G09D90FD6C ]]]]]]]]]]]]]]]]]]]] SL92D9NQ
 
N

:7 , QSL&$t#NQ l Q@C24=6Q \@ QSL&$t#NQ l QC@@EQ .j E96?
  649@ Qt##~#i $6 6DE2 6>A=62?5@ 6= FDF2C:@ @C24=6 @ 6= FDF2C:@ C@@E Q
  649@ Qt;64FE2C 4@? 6= FDF2C:@ 25>:?:DEC25@C 4C625@ 6? =2 :?DE2=24:ó? Q
  6I:Ej
7:

649@ QQ
7G096256C

649@ QQ
649@ Qllllllll `] '2=:52?5@ G2C:23=6D 56 6?E@C?@ lllllllllllllQ

:7  , \5 QSL~#pr{t0w~|tNQ .j  E96?
  649@ Qlllm `] QSW7G0=:DE0AC67:I `XQ ~z \ '2C:23=6 ~#pr{t0w~|tQ   
6=D6
  649@ Qt##~#i 5:C64E@C:@ ?@ 6?4@?EC25@ A2C2 =2 G2C:23=6 ~#pr{t0w~|ti SL~#pr{t0w~|tN Q
7:j

:7  ,, QSL4@?7:8w@DEDNQ lO 7:-]F?2> ..j E96?
  649@ Qlllm a] SW7G0=:DE0AC67:I aX ~z r@?7:8FC24:ó? 6? ^6E4^9@DED 4@?E:6?6 7:]F?2>Q
6=D6
  649@ Qt##~#i t= 2C49:G@ ^6E4^9@DED ?@ 4@?E:6?6 6= 5@>:?:@ 7:]F?2>Q
7:j

:7  ,, QSL4@?7:8w@DE?2>6NQ lO 7:-]F?2> ..j E96?
  649@ Qlllm b] SW7G0=:DE0AC67:I bX ~z r@?7:8FC24:ó? 6? ^6E4^9@DE?2>6 4@?E:6?6 7:]F?2>Q
6=D6
  649@ Qt##~#i t= 2C49:G@ ^6E4^9@DE?2>6 ?@ 4@?E:6?6 6= 5@>:?:@ 7:]F?2>Q
7:j

A2C2>0<6C?6=l1DJD4E= \B 7D]2:@\>2I\?C1
:7 , QSLA2C2>0<6C?6=NQ l Q7D]2:@\>2I\?C l `_cgdfeQ .j E96?
  649@ Qlllm c] QSW7G0=:DE0AC67:I cXQ ~z \ A2C2>6EC@ 56= <6C?6= 7D]2:@\>2I\?C Q   
6=D6
  649@ Qt##~#i G2=@C :?G2=:5@ A2C2 A2C2>6EC@ 56= <6C?6= 7D]2:@\>2I\?C Q
  649@ Q$6 6DA6C232 V7D]2:@\>2I\?C l `_cgdfeV[ D6 @3EFG@i SLA2C2>0<6C?6=N Q
7:j

7:=60D:K6l1DE2E \4TD SL~#pr{t0w~|tN^3:?^@C24=61
:7 P , QSL7:=60D:K6NQ l Q_Q .j E96?
  649@ Qlllm d] QSW7G0=:DE0AC67:I dXQ ~z \ {@?8:EF5 56= 2C9:G@ @C24=6i SL7:=60D:K6NQ   
6=D6
  649@ Qt##~#i t= 2C49:G@ 3:?2C:@ E:6?6 _ 3JE6D] {2 ACá4E:42 6D :?Gá=:52] Q
  649@ Q!2C2 4@CC68:C 6= 6CC@C D6 5636Cá C6:?DE2=2C 6= D@7EH2C6 Q
7:j
649@ QQ
649@ Qllllllll a] |@DEC2?5@ C49:G@D 56 :?DE2=24:@? lllllllllllllQ
=D \= S~#pr{t0w~|t^3:?^@C24=6
=D \= S~#pr{t0w~|t^3:?^DB=A=FD
=D \= S~#pr{t0w~|t^3:?^=D?C4E= 
=D \= O^]32D9C4
649@ Q{:DE@ PQ
