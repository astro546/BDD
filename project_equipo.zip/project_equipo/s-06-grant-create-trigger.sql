connect sys/system@rdvgbdd_s1 as sysdba
grant create trigger to autos_bdd;
connect sys/system@rdvgbdd_s2 as sysdba
grant create trigger to autos_bdd;
connect sys/system@aeggbdd_s1 as sysdba
grant create trigger to autos_bdd;
connect sys/system@aeggbdd_s2 as sysdba
grant create trigger to autos_bdd;