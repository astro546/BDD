insert into status_auto(status_auto_id,clave,descripcion) values(1,'EN TRANSITO','En camino a la agencia');
insert into status_auto(status_auto_id,clave,descripcion) values(2,'EN AGENCIA','Disponible en la agencia para venta');
insert into status_auto(status_auto_id,clave,descripcion) values(3,'APARTADO','El cliente ha realizado un dep�osito');
insert into status_auto(status_auto_id,clave,descripcion) values(4,'VENDIDO','El carro se ha vendido');
insert into status_auto(status_auto_id,clave,descripcion) values(5,'DEFECTUOSO','Autos nuevos con defectos');
insert into status_auto(status_auto_id,clave,descripcion) values(6,'EN REPARACION','Para autos vendidos en reparacion');